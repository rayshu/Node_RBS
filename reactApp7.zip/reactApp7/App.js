import React, { Component } from 'react';
import { Link, Route, Switch } from 'react-router-dom';
class App extends React.Component {
   render() {
      return (
         <div>
            <nav className="navbar navbar-light">
               <ul className="nav navbar-nav">
                  <li><Link to="/">Homes</Link></li>
                  <li><Link to="/aboutus">Aboutus</Link></li>
                  <li><Link to="/contactus">Contactus</Link></li>
                  <li><Link to="/projects">Projects</Link></li>
                  <li><Link to="/charity">Charity</Link></li>
               </ul>
            </nav>
         </div>
      );
   }
}
export default App;