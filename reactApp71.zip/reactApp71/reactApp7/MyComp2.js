import React, { Component } from 'react';


var arr = [{
    "bookid": 101,
    "bname": "Pelican Brief",
    "bauthor": "John Grisham"
}, {
    "bookid": 102,
    "bname": "veteran",
    "bauthor": "Forsyth"
}, {
    "bookid": 103,
    "bname": "Midnight Children",
    "bauthor": "Salman Rushdie"
}, {
    "bookid": 104,
    "bname": "Not A Penny Less Not A Penny More",
    "bauthor": "John Grisham"
}, {
    "bookid": 105,
    "bname": "Never Say Die",
    "bauthor": "Tess"
}];


export class MyComp2 extends React.Component {
    render() {
        return (
            <div>
                {
                    arr.map(book => <Details key={book.bookid} data={book} />)
                }
            </div>
        );
    }

}


class Details extends React.Component {
    render() {
        return (

            <div class="card-deck">
                <div class="card bg-danger">
                    <div class="card-body text-center">
                        <p class="card-text">{this.props.data.bookid}</p>
                        <p class="card-text">{this.props.data.bname}</p>
                        <p class="card-text">{this.props.data.bauthor}</p>
                        <p class="card-text"><a href="emailto:satish@yahoo.com">Mail Me</a></p>
                    </div>
                   
                </div>
                <div><br/><hr/><hr/><br/></div>
            </div>
        );
    }
}

export default MyComp2;


