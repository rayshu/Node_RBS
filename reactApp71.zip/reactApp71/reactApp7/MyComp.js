import React, { Component } from 'react';
var arr = [{
    "id": 1,
    "name": "satish",
    "email": "himanshu091190@hotmail.com"
},
{
    "id": 2,
    "name": "sumathi",
    "email": "himanshu091190@gmail.com"
},
{
    "id": 3,
    "name": "sarada",
    "email": "himanshu091190@yahoo.com"
},
{
    "id": 4,
    "name": "ramakrishna",
    "email": "ram@hotmail.com"
},
{
    "id": 5,
    "name": "sridhar",
    "email": "ram@gmail.com"
},
{
    "id": 6,
    "name": "smitha",
    "email": "ram@yahoo.com"
}
];

export class MyComp extends React.Component {

    render() {
        return (
            <div className="alert alert-success">
                <table className="table table striped">
                    {
                        arr.map(a => <MyRow key={a.id} data={a} />)
                    }
                </table>
            </div>
        );
    }
}

class MyRow extends React.Component {

    render() {
        return (
            <tr>
                <td>{this.props.data.id}</td>
                <td>{this.props.data.name}</td>
                <td>{this.props.data.email}</td>
            </tr>
        );
    }








}

export default MyComp;