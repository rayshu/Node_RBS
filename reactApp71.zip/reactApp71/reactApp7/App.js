import React, { Component } from 'react';
import { MyComp } from "./MyComp";
import { MyComp2 } from './MyComp2';


class App extends React.Component {
    render() {
        return (
            <div>
                <div class="row">
                    <div class="col"><Header /></div>
                    <div class="col"><MyComp /></div>
                    <div class="col"><Footer /></div>
                </div>
                
            </div>
        );
    }
}


class Header extends React.Component {
    render() {
        return (
            <div>
                <nav class="navbar navbar-expand-sm bg-light">


                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="#">home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">about us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">contact us</a>
                        </li>
                    </ul>

                </nav>
            </div>
        );
    }
}

class Footer extends React.Component {
    render() {
        return (
            <div>
                This site is Maintained and managed by &copy; <span className="badge badge-secondary">Himanshu Sharma</span>
            </div>
        );
    }

}
export default App;