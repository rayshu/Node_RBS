import React, { Component } from 'react';
import { DdlComp } from './DdlComp';


class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            uname: '',
            pwd: ''
        };
        this.onSub = this.onSub.bind(this);
        this.onCh1 = this.onCh1.bind(this);
        this.onCh2 = this.onCh2.bind(this);
    }

    onSub(e) {
        alert(this.state.uname + ' ' + this.state.pwd);
        e.preventDefault();
    }
    onCh1(e) {
        console.log(e.target.value);
        this.setState({ uname: e.target.value });
    }
    onCh2(e) {
        console.log(e.target.value);
        this.setState({ pwd: e.target.value });
    }



    render() {
        return (
            <div>
                <form onSubmit={this.onSub}>
                    <table className="table table-bordered">
                        <tr><td>USERNAME</td><td><input type="text" name="uname" onChange={this.onCh1} /></td></tr>
                        <tr><td>PASSWORD</td><td><input type="password" name="pwd" onChange={this.onCh2} /></td></tr>
                        <tr><td><input className="btn btn-danger" type="submit" value="Login" /></td><td><input className="btn btn-info" type="reset" value="Cancel" /></td></tr>
                    </table>
                </form>
                <span><button>{this.state.uname}</button></span><span><button>{this.state.pwd}</button></span>
                <br/>
                <br/>
                <DdlComp />
            </div>
        );
    }
}

export default App;